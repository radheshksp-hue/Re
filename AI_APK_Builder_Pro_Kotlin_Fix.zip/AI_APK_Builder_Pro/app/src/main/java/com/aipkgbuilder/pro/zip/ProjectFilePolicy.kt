package com.aipkgbuilder.pro.zip

import java.io.File
import java.util.Locale

/** Shared packaging exclusion policy so the exact security rules can be unit-tested. */
object ProjectFilePolicy {
    private val excludedDirs = setOf(".git", ".gradle", "build", "node_modules", ".kotlin", ".idea")
    private val sensitivePath = Regex("(?i)(^|/)(local\\.properties|signing\\.properties|secrets?\\.properties|credentials?[^/]*|service-account[^/]*\\.json|id_rsa|id_ed25519|\\.env(?:\\.[^/]*)?)$|(?i)\\.(jks|keystore|p12|pfx|pem|p8|key)$")
    private val sensitiveContent = Regex("(?i)(?:api[_-]?key|access[_-]?token|client[_-]?secret|password|private[_-]?key|ghp_|github_pat_|AIza)[\"'\\s:=]{1,8}[A-Za-z0-9_./+=-]{12,}")

    fun shouldSkipDirectory(relativePath: String): Boolean =
        relativePath.replace('\\', '/').split('/').any { it in excludedDirs }

    fun shouldExcludeFile(file: File, relativePath: String): Boolean {
        val rel = relativePath.replace('\\', '/')
        if (rel.split('/').any { it in excludedDirs }) return true
        if (sensitivePath.containsMatchIn(rel) || file.name.equals("local.properties", true)) return true
        if (file.length() <= 512L * 1024L && file.extension.lowercase(Locale.US) in
            setOf("xml", "json", "properties", "gradle", "kts", "txt", "conf", "yaml", "yml")) {
            val text = runCatching { file.readText(Charsets.UTF_8) }.getOrNull()
            if (text != null && sensitiveContent.containsMatchIn(text)) return true
        }
        return false
    }
}

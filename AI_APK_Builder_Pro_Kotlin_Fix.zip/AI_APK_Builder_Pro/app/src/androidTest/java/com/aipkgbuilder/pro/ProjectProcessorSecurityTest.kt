package com.aipkgbuilder.pro

import androidx.test.core.app.ApplicationProvider
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.aipkgbuilder.pro.zip.ProjectProcessor
import com.aipkgbuilder.pro.zip.ZipSafetyException
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

@RunWith(AndroidJUnit4::class)
class ProjectProcessorSecurityTest {
    private val context = ApplicationProvider.getApplicationContext<android.content.Context>()

    private fun copyAsset(name: String): File = File(context.cacheDir, name).also { target ->
        InstrumentationRegistry.getInstrumentation().context.assets.open(name).use { input -> target.outputStream().use { input.copyTo(it) } }
    }

    @Test fun rejectsMalformedZip() {
        val archive = copyAsset("malformed.zip")
        try {
            try { ProjectProcessor(context).extractAndAnalyze(archive, File(context.cacheDir, "bad-${System.nanoTime()}")); fail("Malformed ZIP must be rejected") }
            catch (expected: ZipSafetyException) { assertTrue(expected.message.orEmpty().contains("ZIP", true)) }
        } finally { archive.delete() }
    }

    @Test fun rejectsZipSlipBeforeExtraction() {
        val archive = copyAsset("path-traversal.zip")
        val workspace = File(context.cacheDir, "traversal-${System.nanoTime()}")
        try {
            try { ProjectProcessor(context).extractAndAnalyze(archive, workspace); fail("Path traversal must be rejected") }
            catch (expected: ZipSafetyException) { assertTrue(expected.message.orEmpty().contains("traversal", true) || expected.message.orEmpty().contains("unsafe", true)) }
            assertFalse(File(context.cacheDir, "escape.txt").exists())
        } finally { archive.delete(); workspace.deleteRecursively() }
    }

    @Test fun extractsAndDetectsNestedValidProject() {
        val archive = copyAsset("valid-nested-project.zip")
        val workspace = File(context.cacheDir, "valid-${System.nanoTime()}")
        try {
            val summary = ProjectProcessor(context).extractAndAnalyze(archive, workspace)
            assertEquals("ValidFixture", summary.detectedName)
            assertTrue(summary.modules.any { it.name == "app" && it.applicationModule })
            assertTrue(summary.hasManifest)
        } finally { archive.delete(); workspace.deleteRecursively() }
    }
}
